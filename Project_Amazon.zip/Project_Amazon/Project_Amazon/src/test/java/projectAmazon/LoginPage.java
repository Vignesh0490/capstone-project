package projectAmazon;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class LoginPage {

	WebDriver driver;

	public void loginWithGmail(WebDriver driver) throws Exception {

		this.driver = driver;
		driver.get("https://www.amazon.in/");		
		WebElement accountButtonLogin = driver.findElement(By.xpath("//span[text()='Account & Lists']"));
		Actions actions = new Actions(driver);
		actions.moveToElement(accountButtonLogin);
		
		// To navigate to the sign-in Path
		WebElement signInButton = driver.findElement(By.xpath("//span[text()='Sign in']"));
		actions.moveToElement(signInButton);
		actions.click().build().perform();
		
		
		WebElement email = driver.findElement(By.id("ap_email"));
		email.sendKeys("vikevignesh+test2@gmail.com");
		WebElement continueButton = driver.findElement(By.id("continue"));
		continueButton.click();
		WebElement password = driver.findElement(By.id("ap_password"));
		password.sendKeys("Global@123");
		WebElement signIn = driver.findElement(By.id("signInSubmit"));
		signIn.click();
		
		Thread.sleep(5000);
		File screenShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenShotFile, new File(".//screenshot/screen.png"));
	
	}

}
