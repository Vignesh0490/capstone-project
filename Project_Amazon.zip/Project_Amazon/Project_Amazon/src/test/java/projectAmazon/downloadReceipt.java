package projectAmazon;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class downloadReceipt extends BuyItem {

	LoginPage lp = new LoginPage();
	SearchItem si = new SearchItem();
	BuyItem bi = new BuyItem();

	@BeforeClass
	public void setUp() {
		// System.setProperty("Webdriver.chrome.driver","C:\\Users\\mourov\\Downloads\\Atlas\\Capstone\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
	}

	@Test(priority = 1)
	public void reviewOrder() throws Exception {

		lp.loginWithGmail(driver);
		si.searchAndViewElectronics(driver);
		si.searchAndViewFashion(driver);
		//bi.enterShippingAddress(driver);
		bi.enterPaymentDetails(driver);
		bi.buyTheOrder(driver);

		WebElement reviewOrder = driver.findElement(By.xpath("//span[text()='Review or edit your recent orders']"));
		reviewOrder.click();

		WebElement downloadInvoice = driver.findElement(By.xpath("//a[contains(text(),'Invoice')]"));
		downloadInvoice.click();

		WebElement printableOrderSummary = driver.findElement(By.xpath(
				"//span[@class='a-list-item']//a[@class='a-link-normal' and contains(text(),'Printable Order Summary')]"));
		printableOrderSummary.click();
		//ArrayList<String> newWindow = new ArrayList<>(driver.getWindowHandles());
		//driver.switchTo().window(newWindow.get(3));
		Thread.sleep(8000);
		String printMessage = "Print this page for your records.";
		Assert.assertEquals("Print this page for your records.", printMessage);

	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}

}
