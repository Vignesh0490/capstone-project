package projectAmazon;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class SignupPage {

	WebDriver driver;

	@BeforeClass
	public void setUp() {
		// System.setProperty("Webdriver.chrome.driver","C:\\Users\\mourov\\Downloads\\Atlas\\Capstone\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void signUpWithGmail() throws Exception {
		driver.get("https://www.amazon.in/");
		// xpath is to navigate through the HTML structure of the page
		WebElement accountButton = driver.findElement(By.xpath("//span[text()='Account & Lists']"));
		// Actions class is an ability provided by Selenium for handling keyboard and
		// mouse events.
		Actions actions = new Actions(driver);
		actions.moveToElement(accountButton);

		WebElement startHere = driver.findElement(By.xpath("//a[text()='Start here.']"));
		actions.moveToElement(startHere);
		actions.click().build().perform();

		WebElement yourName = driver.findElement(By.id("ap_customer_name"));
		yourName.sendKeys("Vignesh");
		WebElement mobileNum = driver.findElement(By.id("ap_phone_number"));
		mobileNum.sendKeys("8838485283");
		WebElement email = driver.findElement(By.id("ap_email"));
		email.sendKeys("vigneshtestng+test1@gmail.com");
		WebElement password = driver.findElement(By.id("ap_password"));
		password.sendKeys("Mavmp@123");
		WebElement verifyMobile = driver.findElement(By.id("continue"));
		verifyMobile.click();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement createAccountSameMob = driver.findElement(By.xpath("//a[contains(text(),'this mobile number')]"));
		createAccountSameMob.click();
		WebElement createNewAccountAnyway = driver.findElement(By.id("auth-account-conflict-continue-verify-url"));
		createNewAccountAnyway.click();

		// verify the email address page
		// WebElement enterOTP = driver.findElement(By.xpath("//input[@name =
		// 'code']"));
		// enterOTP.sendKeys("OTP");
		Thread.sleep(30000);
		WebElement createAccount = driver.findElement(By.id("auth-verify-button"));
		createAccount.click();

		// Assertion for successful login
		WebElement loggedInUser = driver.findElement(By.id("nav-link-accountList-nav-line-1"));
		String actualMessage = loggedInUser.getText();
		String expectedMessage = "Hello, Vignesh";
		Assert.assertEquals(actualMessage, expectedMessage);
	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}
}
