package com.testNG;

public class Calc {
public int add(int a,int b)
{
	int c=a+b;
	return c;}
}
